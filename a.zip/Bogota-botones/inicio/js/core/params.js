class params {
    constructor() {
		this.urlParamSimulator = 'https://creditodigital.bancodebogota.co/';
		this.urlParamFlew      = 'https://creditodigital.bancodebogota.co/#/authenticator-handler';
		this.tagManager        = 'GTM-MDK3STF';
		this.urlPreAuth        = 'https://preauth.creditodigital.bancodebogota.co/user-info';
        this.preAuth           = 'preauth';
    }
}
